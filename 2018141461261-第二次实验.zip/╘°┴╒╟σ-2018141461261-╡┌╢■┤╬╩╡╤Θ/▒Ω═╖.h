#ifndef test
#define test

#include <iostream>
#include <stack>
#include <cmath>
using namespace std;

class cal {
protected:
	stack<double> *val;
	stack<char> *ops;
	char *str;
public:
	cal();
	cal(char* p);
	~cal();
	int compare(char x, char y);//�Ƚ���������ȼ�
	double calculate(int &flag3);
};

int cal::compare(char x, char y) {
	if ((x == '*' || x == '/') && (y == '+' || y == '-')) {
		return 1;//���ȼ�x>y
	}
	if (y == '(') return 1;
	else return 0;
}

cal::cal() {
	this->ops = new stack<char>;
	this->val = new stack<double>;
	str = new char[100];
}

cal::cal(char* p) {
	this->ops = new stack<char>;
	this->val = new stack<double>;
	str = p;
}

cal::~cal() {
	delete ops;
	delete val;
	delete str;
}

double cal::calculate(int &flag3) {
	char p = this->str[0];
	double value = 0;
	int i = 0,flag = 0;
	while (1) {
		if (p != '*' && p != '/' && p != '+' && p != '-' && p != ')' && p != '(' && p != 0&&(p<'0'||p>'9')) {
			cout << "the expression is wrong  and the result is untrustable" << endl;
			flag3 = 0;
			break;
		}
		if (p == '*' || p == '/' || p == '+' || p == '-' || p == ')' || p == '('||p==0) {//����Ƿ���
			if (this->str[i] == '-' && (i == 0 || this->str[i - 1] == '(')) flag = -1;
			else if (this->ops->empty() && p != 0) this->ops->push(p);
			else if (p != ')' && !this->ops->empty()&& this->compare(p, this->ops->top()) == 0 && p != '(') {
				if (this->val->empty()) {
					cout << "the expression is wrong  and the result is untrustable" << endl;
					flag3 = 0;
					break;
				}
				value = this->val->top();
				char k = this->ops->top();
				this->val->pop();
				this->ops->pop();
				if (k == '+'&&!this->val->empty()) value += this->val->top();
				if (k == '-'&&flag == 0 && !this->val->empty()) value = this->val->top()-value;
				if (k == '*' && !this->val->empty()) value *= this->val->top();
				if (k == '/' && !this->val->empty()) value = this->val->top()/value;
				if (!this->val->empty())this->val->pop();
				else {
					cout << "the expression is wrong  and the result is untrustable" << endl;
					flag3 = 0;
					break;
				}
				if(p!=0) this->ops->push(p);
				this->val->push(value);//���Լ���
			}
			else if (p != ')' && !this->ops->empty()&&this->compare(p, this->ops->top()) == 1 || this->ops->top() == '(' || p == '(') {
				if (this->val->empty()) {
					cout << "the expression is wrong  and the result is untrustable" << endl;
					flag3 = 0;
					break;
				}
				ops->push(p);//ѹջ���
			}
			else if (p == ')') {
				value = this->val->top();
				this->val->pop();
				char x;
				while (this->ops->empty()||this->ops->top() != '(') {
					if (this->ops->empty()) {
						cout << "the expression is wrong and the result is untrustable" << endl;
						break;
					}
					x = this->ops->top();
					if (x == '+') value += this->val->top();
					if (x == '-'&&flag ==0) value -= this->val->top();
					if (x == '*') value *= this->val->top();
					if (x == '/') value /= this->val->top();
					this->ops->pop();
					this->val->pop();
				}
				this->val->push(value);
				if (!this->ops->empty()) {
					this->ops->pop();
				}
			}
			if(p!=0) i++;
			if (this->str[i]==0&&this->ops->empty()) break;
			if (this->str[i] == 0 && !this->ops->empty()&&this->val->size()==1) {
				cout << "the expression is wrong  and the result is untrustable" << endl;
				flag3 = 0;
				break;
			}
		}
		else {
			value = 0;
			for (; this->str[i] > 47 && this->str[i] < 58; i++) {
				value = value * 10 + this->str[i]-48;
			}
			if (this->str[i] == '.') {
				i++;
				int count = 0;
				for (; this->str[i] > 47 && this->str[i] < 58; i++) {
					count--;
					double temp = pow(10, count);
					value = value + (this->str[i]-'0') * temp;
				}
			}
			if (flag == -1) {
				value *= -1;
				flag = 0;
			}
			this->val->push(value);
		}
		p = this->str[i];
	}
	if (flag3 == 0) return -1;
	return this->val->top();
}

#endif