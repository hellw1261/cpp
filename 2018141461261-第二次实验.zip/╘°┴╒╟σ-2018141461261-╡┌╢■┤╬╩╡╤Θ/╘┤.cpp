#include "��ͷ.h"
using namespace std;

int main() {
	for (;;) {
		char* p = new char[100];
		cin >> p;
		cal str(p);
		int flag = 1;
		double res = str.calculate(flag);
		if (flag==1)cout << res;
	}
	return 0;
}